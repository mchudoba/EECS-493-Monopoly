Project team:
Alan Seto
Kevin Silang
Matt Chudoba
Parthiv Vora



This directory contains our group's initial version of Monopoly for
Android.

=============== Contents ===============

1. Monopoly.apk

A build of our game for Android

2. Monopoly (folder)

This folder contains our Unity project for the game. Within the folder
there is a folder called Assets, which holds all of our game scripts,
objects, etc. The project is written in Unity 5 and is set up to be
built for Android.