﻿using UnityEngine;
using System.Collections;

public class MovePiece : MonoBehaviour {
	public static bool playerMoving = false;

	public GameController gc;
	public Vector3[] boardSpaces; 
	public Vector3 inJail;
	private int spaceTotal = 32;	//sets number of spaces of board
	public int currentIndex = 0;	//sets the piece's current position
	public int targetIndex = 0;		//sets the piece's target position
	public float speed = 5f; 		//speed for "Vector3.MoveTowards
	public int counter = 0; 		//counter used to control how fast pieces move
	public bool jail = false; 			//true = in jail, false = free
	public bool noCollect = false;		//true = event where you don't collect on go (chance, etc.), false = can collect
	public bool rolled = false;
	public bool initialRoll = false;		//initial roll still has not been rolled

	public Color playercolor;

	public float timer = 0;

	int player = 0; //which player this is; set in Start

	public bool NotAtTarget(){
		return (!jail && transform.position != boardSpaces [targetIndex]) || (jail && transform.position != inJail);
	}

	// Use this for initialization
	void Start () {
		playercolor = GetComponent<Renderer> ().material.color;
		gc = GameObject.Find ("Interface").GetComponent<GameController> ();
		initBoardArray ();	//Initializes the space positioning into arrays for each piece

		if(gameObject.tag == "P1") player = 1;
		else if (gameObject.tag == "P2") player = 2;
		else if (gameObject.tag == "P3") player = 3;
		else player = 4;

		transform.position = boardSpaces [0];
	}
	
	// Update is called once per frame
	void Update () {

		if (NotAtTarget()) {
			playerMoving = true;
			if(currentIndex == 31) {	//If reach end of boardSpaces array
				transform.position = Vector3.MoveTowards (transform.position, boardSpaces [0], speed * Time.deltaTime);
			}
			else if (currentIndex == 9 && jail == true) {	//going to jail
				transform.position = Vector3.MoveTowards (transform.position, inJail, speed * Time.deltaTime);
			}
			else {	//Traverse one space ahead at a time
				transform.position = Vector3.MoveTowards (transform.position, boardSpaces [currentIndex + 1], speed * Time.deltaTime);
			}

			if(transform.position == boardSpaces[(currentIndex + 1) % 32]){
				if ((jail == false || noCollect == false) && ((currentIndex + 1) % 32 == 0)) {
					gc.changeMoney(player, 2);
				} 

				currentIndex = (currentIndex + 1) % 32;

				//decide if turn is over
				if(currentIndex == targetIndex) gc.nextTurn();
			}

			if (transform.position == inJail && jail){
				currentIndex = 9;
			}
		}
		else
			playerMoving = false;
	}


	//Initialize the array of positions for each piece:
	void initBoardArray() {

		boardSpaces = new Vector3[spaceTotal];

		int index = 0;
		int currentIndex = 0;
		float x = -5.3f;
		float y = -7.3f;
		float z = -1f;

		if (gameObject.tag == "P1") {	//sphere
			boardSpaces[index] = new Vector3 (x, y, z); //GO
		}
		else if(gameObject.tag == "P2") {//cube
			x = -4.2f;
			y = -7.3f;
			boardSpaces[index] = new Vector3 (x, y, z);
		}
		else if(gameObject.tag == "P3") {//capsule
			x = -5.3f;
			y = -8.2f;
			boardSpaces[index] = new Vector3 (x, y, z); 
		}
		else if(gameObject.tag == "P4") {//cylinder
			x = -4.2f;
			y = -8.2f;
			boardSpaces[index] = new Vector3 (x, y, z);
		}

		index++;
		
		//left side
		for (; index < 11; index++) {
			if (index == 1) {	//Sets first space after corner
				if(gameObject.tag == "P1") {
					x = -5.3f;
					y = -5.7f;
				}
				else if (gameObject.tag == "P2") {
					x = -4.3f;
					y = -5.7f;
				}
				else if (gameObject.tag == "P3") {
					x = -5.3f;
					y = -6.3f;
				}
				else if (gameObject.tag == "P4") {
					x = -4.3f;
					y = -6.3f;
				}
			}
			else if (index == 10) {	//Sets corner space
				if(gameObject.tag == "P1") {
					x = -5.0f;
					y = 8.4f;
				}
				else if (gameObject.tag == "P2") {
					x = -4.2f;
					y = 8.4f;
				}
				else if (gameObject.tag == "P3") {
					x = -5.4f;
					y = 8.0f;
				}
				else if (gameObject.tag == "P4") {
					x = -5.4f;
					y = 7.3f;
				}
			}
			else if (index != 10) {	//Increment non-corner spaces
				y += 1.5f;
			}

			boardSpaces [index] = new Vector3(x,y,z);	//sets new position at index
		}
		
		//top side
		for (; index < 17; index++) {
			if (index == 11) {	//sets space after corner
				if(gameObject.tag == "P1") {
					x = -3.3f;
					y = 8.2f;
				}
				else if (gameObject.tag == "P2") {
					x = -2.7f;	
					y = 8.2f;
				}
				else if (gameObject.tag == "P3") {
					x = -3.3f;
					y = 7.3f;
				}
				else if (gameObject.tag == "P4") {
					x = -2.7f;
					y = 7.3f;
				}
			}
			else if (index != 16) { //sets non-corner spaces
				x += 1.5f;
			}
			else {	//sets corner space
				if(gameObject.tag == "P1" || gameObject.tag == "P3") {
					x = 4.3f;
				}
				else if (gameObject.tag == "P2" || gameObject.tag == "P4") {
					x = 5.3f;	
				}
			}

			boardSpaces [index] = new Vector3(x,y,z);
		}
		
		//right side 
		for (; index < 27; index++) {
			if (index == 17) {	//sets space after corner
				if(gameObject.tag == "P1") {
					x = 4.3f;
					y = 6.3f;
				}
				else if (gameObject.tag == "P2") {
					x = 5.3f;	
					y = 6.3f;
				}
				else if (gameObject.tag == "P3") {
					x = 4.3f;
					y = 5.7f;
				}
				else if (gameObject.tag == "P4") {
					x = 5.3f;
					y = 5.7f;
				}
			}
			else if (index != 26){ //sets non-corner spaces
				y -= 1.5f;
			}
			else { //sets corner space
				if(gameObject.tag == "P1" || gameObject.tag == "P2") {
					y = -7.3f;
				}
				else if (gameObject.tag == "P3" || gameObject.tag == "P4") {
					y = -8.3f;	
				}
			}
			boardSpaces [index] = new Vector3(x,y,z);
		}
		
		//bottom side
		for (; index < 32; index++) {
			if (index == 27) { //sets space after corner
				if(gameObject.tag == "P1") {
					x = 2.7f;
					y = -7.3f;
				}
				else if (gameObject.tag == "P2") {
					x = 3.3f;	
					y = -7.3f;
				}
				else if (gameObject.tag == "P3") {
					x = 2.7f;
					y = -8.2f;
				}
				else if (gameObject.tag == "P4") {
					x = 3.3f;
					y = -8.2f;
				}
			}
			else { //sets non-corner spaces
				x -= 1.5f;
			}
			boardSpaces [index] = new Vector3(x,y,z);
		}

		//SETS THE INJAIL SPACE ON BOARD
		if (gameObject.tag == "P1") {	//sphere
			inJail = new Vector3(-4.8f, 7.9f, -1f);
		}
		else if(gameObject.tag == "P2") {//cube
			inJail = new Vector3(-4.8f, 7.2f, -1f);
			
		}
		else if(gameObject.tag == "P3") {//capsule
			inJail = new Vector3(-4.2f, 7.9f, -1f);
		}
		else if(gameObject.tag == "P4") {//cylinder
			inJail = new Vector3(-4.2f, 7.2f, -1f);
		}

		//resets index back to start:
		currentIndex = 0;
		index = 0;
	}

	//Moves Object Towards Target Location
	public void moveTowardsTarget(int roll)  {
		targetIndex += roll;
		targetIndex %= 32;
	}

	IEnumerator Begin()
	{
		yield return StartCoroutine(Wait(5f));
	}

	IEnumerator Wait(float delay)
	{
		yield return new WaitForSeconds(delay);
	}
}




