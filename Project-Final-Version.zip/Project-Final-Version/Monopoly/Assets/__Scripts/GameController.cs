﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class GameController : MonoBehaviour {
	public int numPlayers = 4;

	public float initialMoney = 30f;

	public Button menuButton;
	public Text moneyText;

	public GameObject RollPanel;
	public Button tap;
	public Button dieButton;
	public Text tapText;

	public GameObject actionPanel;
	public Button no;
	public Button okay;
	public Text information;
	public Image property;
	public Image chancecard;

	public Text turnText;
	public Text tuitionText;

	//Not sure if you need this for something lol:
	public Sprite chance0;
	public Sprite chance1;
	public Sprite chance2;
	public Sprite chance3;
	public Sprite chance4;
	public Sprite chance5;
	public Sprite chance6;
	public Sprite chance7;
	public Sprite chance8;
	public Sprite chance9;
	public Sprite chance10;
	public Sprite chance11;
	public Sprite chance12;
	public Sprite chance13;
	public Sprite chance14;
	public Sprite chance15;
	public Sprite chance16;
	public Sprite chance17;
	public Sprite chance18;
	public Sprite chance19;
	public Sprite chance20;
	public Sprite chance21;
	public Sprite chance22;
	public Sprite chance23;

	public Image[] properties;
	public int[] propertyPair;
	public float[] propertyPrice;
	public int[] propertyOwner;
	public int propertyActionIndex = 0; //used to specify which property is being bought

	public GameObject P1;
	public GameObject P2;
	public GameObject P3;
	public GameObject P4;
	public GameObject[] players;

	public MovePiece P1mp;
	public MovePiece P2mp;
	public MovePiece P3mp;
	public MovePiece P4mp;

	public int turn = 1;

	public bool initialroll = true;

	public static int tuition = 0;

	//arrays here are 1-indexed, ignore 0
	public float[] money;
	public int[] diceval;
	public GameObject[] playerorder; //players in order of turns
	public int[] playerindex;		 //playerindex[turn] gets you the index of the current player in players[]
	public MovePiece[] mps;

	//public Image[] chanceDrawPile; 
	//public Image[] chanceDiscardPile; 
	//Used for deck of chance cards:
	public List<int> chanceDrawPile;
	public List<int> chanceDiscardPile;
	public int chanceIndex;
	public int discardIndex;
	public int numChance;


	public void nextTurn(){
		++turn;
		if (turn > numPlayers)
			turn = 1;

		turnText.text = "Player " + turn.ToString() + " Turn";
	}

	// Use this for initialization
	void Start () {
		players = new GameObject[5];
		players [1] = P1;
		players [2] = P2;
		players [3] = P3;
		players [4] = P4;


		money = new float[5];
		diceval = new int[5];
		playerorder = new GameObject[5];
		playerindex = new int[5];		//playerindex used for input for what player is doing what...essentially an int
		mps = new MovePiece[5];
		for (int i = 0; i < 5; ++i) {
			money [i] = initialMoney;
			diceval[i] = 0;
			playerindex[0] = 0;
		}

		propertyOwner = new int[32];
		for (int i = 0; i < 32; ++i) {
			propertyOwner[i] = 0;
		}

		playerorder [1] = P1;
		playerorder [2] = P2;
		playerorder [3] = P3;
		playerorder [4] = P4;

		P1mp = P1.GetComponent<MovePiece> ();
		P2mp = P2.GetComponent<MovePiece> ();
		P3mp = P3.GetComponent<MovePiece> ();
		P4mp = P4.GetComponent<MovePiece> ();

		mps [1] = P1mp;
		mps [2] = P2mp;
		mps [3] = P3mp;
		mps [4] = P4mp;

		initializeChancePile (); 
	}
	
	// Update is called once per frame
	void Update () {

		moneyText.text = "P1: $" + money [1].ToString ("F0") + "   P2: $" + money [2].ToString ("F0");

		if (numPlayers >= 3)
			moneyText.text += "\nP3: $" + money[3].ToString ("F0");
		if (numPlayers == 4)
			moneyText.text += "   P4: $" + money[4].ToString ("F0");

		if (money [1] <= 0 || money [2] <= 0 || money [3] <= 0 || money [4] <= 0) {
			int maxindex = 1;
			float maxval = 0;
			for(int i = 1; i < 5; ++i){
				if(maxval < money[i]){
					maxval = money[i];
					maxindex = i;
				}
			}

			showMessage("Player " + maxindex + " wins with $" + maxval.ToString("F0") + "!");

		}

		if (Dice.rolling || actionPanel.activeInHierarchy ||
		    (P1mp.NotAtTarget() || P2mp.NotAtTarget() || P3mp.NotAtTarget() || P4mp.NotAtTarget())) {
			//if the die is rolling, or the actionpanel is up, or a piece is moving,
			//	disallow tap to roll
			tap.gameObject.SetActive (false);
			dieButton.interactable = false;
			tapText.gameObject.SetActive(false);
		} else {
			if(!(tap.gameObject.activeInHierarchy)){
				if(mps[turn].jail){
					mps[turn].jail = false;
					mps[turn].noCollect = false;
					return;
				}
				tap.gameObject.SetActive(true);
				dieButton.interactable = true;
				tapText.gameObject.SetActive(true);
			}

			if(diceval[turn] > 0 && !initialroll){
				mps[turn].moveTowardsTarget(diceval[turn]);
				tap.gameObject.SetActive(false);
				dieButton.interactable = false;
				tapText.gameObject.SetActive(false);

				//Does something depending on what space it lands:
				switch (mps[turn].targetIndex) {
				case 0: //GO!
					//Nothing, should Add $200 in MovePiece.cs *Parthiv implemented*
					diceval[turn] = 0;
					break;
				case 3: case 7: case 14: case 18: case 24: case 28: //CHANCE SPACES
					landOnChance(playerindex[turn]);
					diceval[turn] = 0;
					break;
				case 5: case 20: //Pay $2 to Participate in the Hackathon/ Design expo
					//Change money on player 
					showMessage("Pay $2 to participate in the hackathon");
					changeMoney(playerindex[turn], -2);
					//Add money to "Free Tuition" 
					tuition += 2;
					tuitionText.text = "$" + tuition.ToString ();
					diceval[turn] = 0;
					break;
				case 6: case 11: case 22: case 30: //ROLL AGAIN! Northwood, Commuter/Souther, Bursley/Baits, Diag
					//Roll again
					showMessage("You caught a bus to north campus. Roll again");
					turn--;
					//ButtonRoll ();
					diceval[turn + 1] = 0;
					break;	
				case 10: //Visiting
					//DO NOTHING!
					diceval[turn] = 0;
					break;
				case 16: //FREE TUITION
					//Collect all the money that is stocked up on this space
					showMessage("Free tuition! You collected $" + tuition.ToString("F0"));
					changeMoney(playerindex[turn], tuition);
					tuition = 0; 
					tuitionText.text = "$0";
					diceval[turn] = 0;
					break;
				case 26: //Go to JAIL
					changeMoney(playerindex[turn],-3f);
					mps[turn].jail = true;
					mps[turn].noCollect = true;
					mps[turn].targetIndex = 10;
					showMessage("Go to GG Brown, get lost, and lose a turn.");
					diceval[turn] = 0;
					nextTurn();
					break;
				default: //Properties:
					//INSERT PROPERTY IMPLEMENTATION:
					handleProperty(mps[turn].targetIndex);
					diceval[turn] = 0;
					break;
				}

			}
		}
	}

	public void ButtonRoll(){
		diceval [turn] = Dice.Roll ();

		//after initial setup
		if (initialroll && turn == numPlayers) {
			initialroll = false;

			diceval [0] = -1;
			int counter = 1;
			while (diceval[0] < 0) {
				int ind = diceval.ToList ().IndexOf (diceval.Max ());
				switch (ind) {
				case 1:
					playerorder [counter] = P1;
					playerindex [counter] = 1;
					mps[counter] = P1mp;
					break;
				case 2:
					playerorder [counter] = P2;
					playerindex [counter] = 2;
					mps[counter] = P2mp;
					break;
				case 3:
					playerorder [counter] = P3;
					playerindex [counter] = 3;
					mps[counter] = P3mp;
					break;
				case 4:
					playerorder [counter] = P4;
					playerindex [counter] = 4;
					mps[counter] = P4mp;
					break;
				default:
					break;
				}

				diceval [ind] = 0;
				++counter;
				if (counter > 4)
					diceval [0] = 0;
			}

			return; //no moving on initial roll
		} else if (initialroll == true && turn != 4) {	//Rolling for order, do nothing until all 4 players roll
			nextTurn();
			return; 
		} else {
			//actual movement occurs in update once dice is no longer moving
			//whatever function occurs on that space will happen here
		}
	}

	//send index of player (P1 is 1) and amount to add. Negative amount subtracts money.
	public void changeMoney(int player, float amount){
		money [player] += amount;
	}


	//Draws a random Chance Card from array and then does the action specified:
	public void landOnChance(int player) {
		//Image chanceIndex = chanceDrawPile[Random.Range(0, chanceDrawPile.Length)];
		chanceIndex = Random.Range (0, chanceDrawPile.Count); //Get random card

		//Goes to chanceDrawPile, gets corresponding Chance Card, does Action:
		switch(chanceIndex) {
		case 0:
			//Space 13:
			//NEED TO PUT SOMETHING TO MAKE IT STOP/THE INTERFACE STUFF
			showChanceCard(chance0);
			mps[turn].targetIndex = 13;
			//Is the GO thing working? Yes
			break;
		case 1:
			//Space 22:
			showChanceCard(chance1);
			mps[turn].targetIndex = 22;
			turn--;
			diceval[turn + 1] = 0;
			break;
		case 2:
			//Space 11:
			showChanceCard(chance2);
			mps[turn].targetIndex = 11;
			turn--;
			diceval[turn + 1] = 0;
			break;
		case 3:
			//Space 20:
			showChanceCard(chance3);
			mps[turn].targetIndex = 20;
			//Change money on player 
			changeMoney(playerindex[turn],-2);
			//Add money to "Free Tuition" 
			tuition += 2;
			tuitionText.text = "$" + tuition.ToString ();
			break;
		case 4:
			//Space 30:
			showChanceCard(chance4);
			mps[turn].targetIndex = 30;
			turn--;
			diceval[turn + 1] = 0;
			break;
		case 5:
			//Space 12:
			showChanceCard(chance5);
			mps[turn].targetIndex = 12;
			break;
		case 6:
			//Space 29:
			showChanceCard(chance6);
			mps[turn].targetIndex = 29;
			break;
		case 7:
			//Space 10:
			showChanceCard(chance7);
			changeMoney(playerindex[turn], -3);
			mps[turn].targetIndex = 10;
			break;
		case 8:
			//Space 0:
			showChanceCard(chance8);
			mps[turn].targetIndex = 0;
			break;
		case 9:
			//Space 5:
			showChanceCard(chance9);
			mps[turn].targetIndex = 5;
			//Change money on player 
			changeMoney(playerindex[turn],-2);
			//Add money to "Free Tuition" 
			tuition += 2;
			tuitionText.text = "$" + tuition.ToString ();
			break;
		case 10:
			//Space 6:
			showChanceCard(chance10);
			mps[turn].targetIndex = 6;
			turn--;
			diceval[turn + 1] = 0;
			break;
		case 11: 
			//Space 25:
			showChanceCard(chance11);
			mps[turn].targetIndex = 25;
			break;
		case 12:
			//INSERT Function for free pizza stands
			showChanceCard(chance12);
			freeProperty(25);
			break;
		case 13:
			//INSERT Function for free pizza stands
			showChanceCard(chance13);
			freeProperty(4);
			break;
		case 14:
			//INSERT Function for free pizza stands
			showChanceCard(chance14);
			freeProperty(4);
			break;
		case 15: 
			//INSERT Function for free pizza stands
			showChanceCard(chance15);
			freeProperty(17);
			break;
		case 16: 
			//INSERT Function for free pizza stands
			showChanceCard(chance16);
			freeProperty(17);
			break;
		case 17: 
			//INSERT Function for free pizza stands
			showChanceCard(chance17);
			freeProperty(1);
			break;
		case 18: 
			//INSERT Function for free pizza stands
			showChanceCard(chance18);
			freeProperty(13);
			break;
		case 19:
			//INSERT Function for free pizza stands
			showChanceCard(chance19);
			freeProperty(13);
			break;
		case 20: 
			//INSERT Function for free pizza stands
			showChanceCard(chance20);
			freeProperty(29);
			break;
		case 21: 
			//INSERT Function for free pizza stands
			showChanceCard(chance21);
			freeProperty(29);
			break;
		case 22: 
			//INSERT Function for free pizza stands
			showChanceCard(chance22);
			freeProperty(21);
			break;
		case 23: 
			//INSERT Function for free pizza stands
			showChanceCard(chance23);
			freeProperty(21);
			break;
		} //End of conditionals for drawn chance card

		//Now Add Drawn Chance Card to chanceDiscardPile and delete it from chanceDrawPile
		chanceDiscardPile.Add (chanceIndex);
		chanceDrawPile.RemoveAt (chanceIndex);
	
		//If no more draw pile, make discard new draw pile
		if (chanceDrawPile.Count == 0) {
			chanceDrawPile = chanceDiscardPile;
		}

	
	}

	public void initializeChancePile() {
		chanceDrawPile = new List<int>();
		chanceDiscardPile = new List<int>();
		numChance = 24;
		discardIndex = 0;

		for (int i = 0; i < numChance; i++) {
			chanceDrawPile.Add(i);
		}
	}

	public void handleProperty(int index){
		if (propertyPrice [index] == 0)
			return; //not property

		if (propertyOwner [index] == playerindex [turn])
			return; //already owned

		if (propertyOwner [index] != 0) { //someone else owns
			float price = propertyPrice [index];

			if (propertyOwner [index] == propertyOwner [propertyPair [index]])
				price *= 2; //owner has both spaces in pair

			money [playerindex [turn]] -= price;
			money [propertyOwner [index]] += price;

			return;
		}

		//buy a property
		propertyActionIndex = index;
		showProperty (properties[index].sprite);
	}

	public void freeProperty(int index){
		if (propertyOwner [index] != 0
			&& propertyOwner [index] == propertyOwner [propertyPair [index]])
			return; //owned by same person

		if (propertyOwner [index] == 0) { //space is free
			properties [index].color = mps [turn].playercolor;
			propertyOwner [index] = playerindex [turn];
			return;
		} else if (propertyOwner [propertyPair [index]] == 0) { //space isn't free, but space's pair is free
			properties [propertyPair[index]].color = mps [turn].playercolor;
			propertyOwner [propertyPair[index]] = playerindex [turn];
			return;
		}

		//both spaces are owned, but by different people
		int pairindex = propertyPair [index];
		if (money [propertyOwner [index]] >= money [propertyOwner [pairindex]]) {
			properties [index].color = mps [turn].playercolor;
			propertyOwner [index] = playerindex [turn];
			return;
		} else {
			properties [pairindex].color = mps [turn].playercolor;
			propertyOwner [pairindex] = playerindex [turn];
			return;
		}
	}

	public void showChanceCard(Sprite card){
		tap.gameObject.SetActive (false);
		dieButton.interactable = false;
		tapText.gameObject.SetActive(false);
		actionPanel.SetActive(true);
		menuButton.interactable = false;
		information.text = "Chance Card";
		no.gameObject.SetActive (false);
		property.gameObject.SetActive (false);
		chancecard.gameObject.SetActive (true);
		chancecard.sprite = card;
		Time.timeScale = 0;
	}

	public void showProperty(Sprite card){
		tap.gameObject.SetActive (false);
		dieButton.interactable = false;
		tapText.gameObject.SetActive(false);
		actionPanel.SetActive(true);
		menuButton.interactable = false;
		information.text = "Buy Property?";
		no.gameObject.SetActive (true);
		property.gameObject.SetActive (true);
		chancecard.gameObject.SetActive (false);
		property.sprite = card;
		Time.timeScale = 0;
	}

	public void showMessage(string msg){
		tap.gameObject.SetActive (false);
		dieButton.interactable = false;
		tapText.gameObject.SetActive(false);
		actionPanel.SetActive(true);
		menuButton.interactable = false;
		information.text = msg;
		no.gameObject.SetActive (false);
		property.gameObject.SetActive (false);
		chancecard.gameObject.SetActive (false);
		Time.timeScale = 0;
	}

	public void NoButton(){
		actionPanel.SetActive (false);
		menuButton.interactable = true;
		Time.timeScale = 1;
	}

	public void OkayButton(){
		if (property.gameObject.activeInHierarchy) {
			properties [propertyActionIndex].color = mps [turn].playercolor;
			propertyOwner [propertyActionIndex] = playerindex [turn];
			money [playerindex [turn]] -= propertyPrice [propertyActionIndex];
			actionPanel.SetActive (false);
			menuButton.interactable = true;
			Time.timeScale = 1;
		} else if (chancecard.gameObject.activeInHierarchy) {
			//handle property for chance based movements
			switch (chanceIndex) {
			case 0:
			case 5:
			case 6:
			case 11:
				handleProperty (mps [turn].targetIndex);
				if (!property.gameObject.activeInHierarchy) {
					actionPanel.SetActive (false);
					menuButton.interactable = true;
					Time.timeScale = 1;
				}
				break;
			default:
				actionPanel.SetActive (false);
				menuButton.interactable = true;
				Time.timeScale = 1;
				break;
			}
			
		} else {
			if (money [1] <= 0 || money [2] <= 0 || money [3] <= 0 || money [4] <= 0) {
				Application.LoadLevel("Main_Menu");
			}
			actionPanel.SetActive (false);
			menuButton.interactable = true;
			Time.timeScale = 1;
		}
	}
}
